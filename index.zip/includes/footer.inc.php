<div class="footer" align="center">
    <?php echo "Copyright &copy; 2020-2021 <br> ".$companyName.". All Rights Reserved."; ?>
</div>