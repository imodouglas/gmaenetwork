<div class="header-home" align="center" style="padding-top:20%">
    <h3>
        Oops! Something Went Wrong
    </h3>
    <p>
        Looks like this page is not available!
    </p>
    <p>
        <a href="/dashboard/home" class="btn btn-primary white-color"> <i class="fas fa-arrow-left"></i>&nbsp; Home </a>
    </p>
</div>